package za.ac.opsc.settingspagedemo;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class helpPage extends AppCompatActivity {
    private Button helpPagebtn;
    TextView howTo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_page);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Help");
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        helpPagebtn = (Button) findViewById(R.id.btn_help);
        howTo = findViewById(R.id.textBox);
        helpPagebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                howTo.setText("1.Login/Register user"+'\n'+
                        "2.Click on which button applies to you as the user and it would take you to the next page" + '\n'+
                        "3.depending on what you clicked it would go to a navigation system on the landmark page"+ '\n'+
                        "If you find any issues please go to Settings to sort out your issue");

            }
        });
    }
}