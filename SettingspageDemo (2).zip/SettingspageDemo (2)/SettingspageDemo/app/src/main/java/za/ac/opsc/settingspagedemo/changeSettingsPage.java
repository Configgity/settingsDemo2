package za.ac.opsc.settingspagedemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.auth.User;

import java.util.List;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.TimeUnit;

public class changeSettingsPage extends AppCompatActivity  {

    ToggleButton toggleButton1, toggleButton2;
    TextView textViewkm, textViewmiles;
    String TAG= "changeSettingsPage";
    RadioGroup rg_Categories;
    String selectedCategory;
    Button save;

    //Firebase
    FirebaseAuth auth;
    FirebaseUser user;
    User currentDatabaseUser;
    DatabaseReference reference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_settings_page);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Change Settings");
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        save = findViewById(R.id.btnSave);
         rg_Categories = findViewById(R.id.rg_settingsCat);
        toggleButton1 = findViewById(R.id.toggleButton2);
        toggleButton2 = findViewById(R.id.toggleButton3);
        textViewkm = findViewById(R.id.textView3);
        textViewmiles = findViewById(R.id.textView4);

        //Firebase Authentication

        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference().child("Users").child(user.getUid());
        reference.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>(){
          @Override
            public void onComplete(@NonNull Task<DataSnapshot> task){
              if(task.isSuccessful()){
                  currentDatabaseUser = task.getResult().getValue(User.class);
                  if(currentDatabaseUser != null){
                    //Toggle the radio button the user's current settings
                      switch(currentDatabaseUser.getCategorySetting()){
                          case "Historical" :{
                              rg_Categories.check(R.id.rb_setting_Historical);
                              selectedCategory = "Historical";
                              break;
                          }
                          case "Nature":{
                              rg_Categories.check(R.id.rb_setting_Nature);
                              selectedCategory = "Nature";
                              break;
                          }
                          case "Art":{
                              rg_Categories.check(R.id.rb_setting_Art);
                              selectedCategory = "Art";
                              break;
                          }
                          case "All":{
                              rg_Categories.check(R.id.rb_setting_All);
                              selectedCategory = "All";
                              break;
                          }
                      }
                  } else{
                      Toast.makeText(changeSettingsPage.this, "Failed to get user settings", Toast.LENGTH_SHORT).show();
                  }
              }
          }

        });

        rg_Categories.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int i) {
                switch(i){
                    case R.id.rb_setting_Historical:{
                        Log.d(TAG, "Checked (cat): Historical");
                        selectedCategory = "Historical";
                        break;
                    }
                    case R.id.rb_setting_Nature:{
                        Log.d(TAG, "Checked (cat): Nature");
                        selectedCategory = "Nature";
                        break;
                    }
                    case R.id.rb_setting_Art:{
                        Log.d(TAG, "Checked (cat): Art");
                        selectedCategory = "Art";
                    }
                    case R.id.rb_setting_All:{
                        Log.d(TAG, "Checked (cat): All");
                        selectedCategory = "All";
                    }
                }

            }
        });

        save.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
               Log.d(TAG, "Saved fired: Cat -"+ selectedCategory);
               currentDatabaseUser.setCategorySetting(selectedCategory);
               boolean isCatUploaded = false;
               reference.child("categorySetting").setValue(currentDatabaseUser.getCategorySetting()).addOnSuccessListener(new OnSuccessListener<Void>() {
                   @Override
                   public void onSuccess(Void unused) {
                       Toast.makeText(changeSettingsPage.this, "Category Updated", Toast.LENGTH_SHORT).show();
                   }
               }).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception e) {
                    Toast.makeText(changeSettingsPage.this, "Category failed to update", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "Error failed to upload settings:" + e.getMessage());
                   }
               });
            }

        });
        toggleButton1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean b) {
                if (toggleButton1.isChecked()) {
                    textViewkm.setText("Kilometres Button is Checked");
                } else {
                    textViewkm.setText("Kilometres Button is unchecked");
                }
            }
        });
        toggleButton2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean b) {
                if (toggleButton2.isChecked()) {
                    textViewmiles.setText("Miles Button is Checked");
                } else {
                    textViewmiles.setText("Miles Button is unchecked");
                }
            }
        });


    }


}