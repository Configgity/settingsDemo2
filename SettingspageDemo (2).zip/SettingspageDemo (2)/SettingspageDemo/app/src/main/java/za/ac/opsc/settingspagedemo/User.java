package za.ac.opsc.settingspagedemo;

/*
* This is User Class
* This class is to store the user's setting data
*
*
* */

import com.google.firebase.auth.FirebaseUser;

public class User {

    private String categorySetting, userName;

    public User(){

    }
    public User(String categorySetting,String userName){
        this.categorySetting = categorySetting;
        this.userName = userName;

    }

    public String getCategorySetting(){
        return categorySetting;
    }
    public void setCategorySetting(String categorySetting){
        this.categorySetting = categorySetting;
    }
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}


